function Page2() {
  return (
    <div id="page2">
      <div id="moving-text">
        <div className="con">
          <h1>EXPRIENCES</h1>
          <div id="gola"></div>
          <h1>ENVIORNMENTS</h1>
          <div id="gola"></div>
          <h1>CONTENT</h1>
          <div id="gola"></div>
        </div>
        <div className="con">
          <h1>EXPRIENCES</h1>
          <div id="gola"></div>
          <h1>ENVIORNMENTS</h1>
          <div id="gola"></div>
          <h1>CONTENT</h1>
          <div id="gola"></div>
        </div>
        <div className="con">
          <h1>EXPRIENCES</h1>
          <div id="gola"></div>
          <h1>ENVIORNMENTS</h1>
          <div id="gola"></div>
          <h1>CONTENT</h1>
          <div id="gola"></div>
        </div>
      </div>

      <div id="page2-bottom">
        <h1>We are a group of design-driven, goal-focused creators, producers, and designers who believe that the details make all the difference.</h1>
        <div id="bottom-part2">
          <img 
            src="https://assets-global.website-files.com/64d3dd9edfb41666c35b15b7/64d3dd9edfb41666c35b15d1_Holding_thumb-p-500.jpg" 
            alt="Team holding"
          />
          <p>We love to create, we love to solve, we love to collaborate, and we love to turn amazing ideas into reality. We're here to partner with you through every step of the process and know that relationships are the most important things we build.</p>
        </div>
      </div>

      <div id="gooey"></div>
    </div>
  );
}

export default Page2;

